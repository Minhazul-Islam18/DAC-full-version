/**
 * App Invoice - Add
 */



 (function () {
   'use strict';  
   const invoiceItemPriceList = document.querySelectorAll('.invoice-item-price'),
     invoiceItemQtyList = document.querySelectorAll('.invoice-item-qty'),
     invoiceDateList = document.querySelectorAll('.date-picker');
 
   // Price
   if (invoiceItemPriceList) {
     invoiceItemPriceList.forEach(function (invoiceItemPrice) {
       new Cleave(invoiceItemPrice, {
         delimiter: '',
         numeral: true
       });
     });
   }
 
   // Qty
   if (invoiceItemQtyList) {
     invoiceItemQtyList.forEach(function (invoiceItemQty) {
       new Cleave(invoiceItemQty, {
         delimiter: '',
         numeral: true
       });
     });
   }
 
   // Datepicker
   if (invoiceDateList) {
     invoiceDateList.forEach(function (invoiceDateEl) {
       invoiceDateEl.flatpickr({
         monthSelectorType: 'static'
       });
     });
   }
 })();
 
 // repeater (jquery)
 $(function () {
   var applyChangesBtn = $('.btn-add-companies'),
   formRepeater = $('.form-repeater'),
     discount,
     tax1,
     tax2,
     discountInput,
     tax1Input,
     tax2Input,
     sourceItem = $('.source-item'),
     adminDetails = {
       'App Design': 'Designed UI kit & app pages.',
       'App Customization': 'Customization & Bug Fixes.',
       'ABC Template': 'Bootstrap 4 admin template.',
       'App Development': 'Native App Development.'
     };
 
   // Prevent dropdown from closing on tax change
   $(document).on('click', '.tax-select', function (e) {
     e.stopPropagation();
   });
 
   // On tax change update it's value value
   function updateValue(listener, el) {
     listener.closest('.repeater-wrapper').find(el).text(listener.val());
   }
 
   // Apply item changes btn
   if (applyChangesBtn.length) {
     $(document).on('click', '.btn-add-companies', function (e) {
    //    var $this = $(this);
    //    tax1Input = $this.closest('.dropdown-menu').find('#taxInput1');
    //    tax2Input = $this.closest('.dropdown-menu').find('#taxInput2');
    //    discountInput = $this.closest('.dropdown-menu').find('#discountInput');
    //    tax1 = $this.closest('.repeater-wrapper').find('.tax-1');
    //    tax2 = $this.closest('.repeater-wrapper').find('.tax-2');
    //    discount = $('.discount');

    //    if (datas.val() !== null) {
    //      updateValue(tax1Input, tax1);
    //    }
 
    //    if (tax2Input.val() !== null) {
    //      updateValue(tax2Input, tax2);
    //    }
 
    //    if (discountInput.val().length) {
    //      $this
    //        .closest('.repeater-wrapper')
    //        .find(discount)
    //        .text(discountInput.val() + '%');
    //    }
     });
   }
 
   // Repeater init
   if (sourceItem.length) {
     sourceItem.on('submit', function (e) {
       e.preventDefault();
     });
     sourceItem.repeater({
       show: function () {
         $(this).slideDown();
         // Initialize tooltip on load of each item
         const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
         tooltipTriggerList.map(function (tooltipTriggerEl) {
           return new bootstrap.Tooltip(tooltipTriggerEl);
         });
       },
       hide: function (e) {
         $(this).slideUp();
       }
     });
   }
 
   // Item details select onchange
   $(document).on('change', '.item-details', function () {
     var $this = $(this),
       value = adminDetails[$this.val()];
     if ($this.next('textarea').length) {
       $this.next('textarea').val(value);
     } else {
       $this.after('<textarea class="form-control" rows="2">' + value + '</textarea>');
     }
   });

 });
 $(()=>{
    $(document).on('click', '.add-btn', function(){
          $parent = $(this).parent().parent().parent().find(".repeater-list");
          $item = $parent[0].firstElementChild.outerHTML;
          $parent.append($item);
      });
      $(document).on('click', '.delete-btn', function(){
          // console.log($(document).find('.repeater-list').find('.item'));
          if ($(document).find('.repeater-list').find('.item').length == 1){
              alert("You need at least one contact person");
          }else{
              $(this).parent().remove();
          }
      });
  })
  function addComp(e) {
    console.log(e);
    const data = document.getElementsByClassName('companiesName');
    let text = "";
    for (let index = 0; index < data.length; index++) {
      var element = data[index].value;
      console.log(element);
      text += element + "<br/>";
    }
    // Append the "li" node to the list:
    document.getElementsByClassName("submitedCompaniesName")[0].innerHTML=text;    
// for(var i=0; i < 1; i++) {
//     var ulList = document.getElementsByClassName("submitedCompaniesName")[0];

//     ulList.append(`
//       <div class="flex"> <span>` + companiesName + `</span>  </div>
//     `)
//   }

}
(function () {
  const TagifyCustomListSuggestionEl = document.querySelector('.TagifyCustomListSuggestion');

  const whitelist = [
    'Company 1',
    'Company 2',
    'Company 3',
    'Company 4',
    'Company 5',
    'Company 6'
  ];
  // Inline
  // let TagifyCustomInlineSuggestion = new Tagify(TagifyCustomInlineSuggestionEl, {
  //   whitelist: whitelist,
  //   maxTags: 10,
  //   dropdown: {
  //     maxItems: 20,
  //     classname: 'tags-inline',
  //     enabled: 0,
  //     closeOnSelect: false
  //   }
  // });
  // List
  let TagifyCustomListSuggestion = new Tagify(TagifyCustomListSuggestionEl, {
    whitelist: whitelist,
    maxTags: 10,
    dropdown: {
      maxItems: 20,
      classname: '',
      enabled: 0,
      closeOnSelect: false
    }
  });
})();

$(function () {
  $('#selectPlan').change(function () {
    console.log($(this).val());
      $('.pack').hide();
      $('.pack-container').find('#' + $(this).val()).fadeIn('slow');
  });
});