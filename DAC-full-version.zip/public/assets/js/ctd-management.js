/**
 * Blog
 */
(function () {
var confirmText = document.querySelector('#confirm-text');
  // Alert With Functional Confirm Button
  if (confirmText) {
    confirmText.onclick = function () {
      Swal.fire({
        title: '<h6 class="m-0 h5">Are you sure to disable this CTD?</h6>',
        text: "Please note that once disabled, the CTD will no longer visible online!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, Disable it!',
        customClass: {
          confirmButton: 'btn btn-primary me-3',
          cancelButton: 'btn btn-label-secondary'
        },
        buttonsStyling: false
      }).then(function (result) {
        if (result.value) {
          Swal.fire({
            icon: 'success',
            title: 'Disabled!',
            text: 'Your file has been disabled.',
            customClass: {
              confirmButton: 'btn btn-success'
            }
          });
        }
      });
    };
  }
})();
$("document").ready(function () {

    $("#dataTableCTDlist").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
          ]
        },
        {
          text: '<i class="bx bx-plus-circle me-sm-2"></i> <span class="d-none d-sm-inline-block">Add New CTD</span>',
          className: 'addPackages btn btn-primary',
          attr: {
            'data-bs-toggle': 'offcanvas',
            'data-bs-target': '#addData'
          }
        }
      ],
    });
  
    //Get a reference to the new datatable
    var table = $('#dataTableCTDlist').DataTable();
  
    //Take the lots filter drop down and append it to the datatables_filter div. 
    //You can use this same idea to move the filter anywhere withing the datatable that you want.
    // $("#dataTable_filter.dataTables_filter").append($("#lotsFilter"));
    // $("#dataTable_filter.dataTables_filter").append($("#countryFilter"));
    
    //Get the column index for the lots column to be used in the method below ($.fn.dataTable.ext.search.push)
    //This tells datatables what column to filter on when a user selects a value from the dropdown.
    //It's important that the text used here (lots) is the same for used in the header of the column to filter

    // var countryIndex = 0;
    // $("#dataTable th").each(function (i) {
    //   if ($($(this)).html() == "Subscribers(Users)") {
    //     countryIndex = i; return false;
    //   }
    // });
    // var sectorIndex = 0;
    // $("#dataTable th").each(function (i) {
    //   if ($($(this)).html() == "Sectors of activities") {
    //     sectorIndex = i; return false;
    //   }
    // });
    // var planIndex = 0;
    // $("#dataTable th").each(function (i) {
    //   if ($($(this)).html() == "Plan (Package)") {
    //     planIndex = i; return false;
    //   }
    // });
    // var statusIndex = 0;
    // $("#dataTable th").each(function (i) {
    //   if ($($(this)).html() == "Account Status") {
    //     statusIndex = i; return false;
    //   }
    // });
  
    //Use the built in datatables API to filter the existing rows by the lots column
    // $.fn.dataTable.ext.search.push(
    //   function (settings, data, dataIndex) {
    //     var selectedItem = $('.countryFilter').val()
    //     var country = data[countryIndex];
    //     if (selectedItem === "" || country.includes(selectedItem)) {
    //       return true;
    //     }
    //     return false;
    //   }
    // );
    // $.fn.dataTable.ext.search.push(
    //   function (settings, data, dataIndex) {
    //     var selectedItem = $('.sectorFilter').val()
    //     var sector = data[sectorIndex];
    //     if (selectedItem === "" || sector.includes(selectedItem)) {
    //       return true;
    //     }
    //     return false;
    //   }
    // );
    // $.fn.dataTable.ext.search.push(
    //   function (settings, data, dataIndex) {
    //     var selectedItem = $('.planFilter').val()
    //     var plan = data[planIndex];
    //     if (selectedItem === "" || plan.includes(selectedItem)) {
    //       return true;
    //     }
    //     return false;
    //   }
    // );

    // $.fn.dataTable.ext.search.push(
    //   function (settings, data, dataIndex) {
    //     var selectedItem = $('.statusFilter').val()
    //     var status = data[statusIndex];
    //     if (selectedItem === "" || status.includes(selectedItem)) {
    //       return true;
    //     }
    //     return false;
    //   }
    // );
  
    //Set the change event for the lots Filter dropdown to redraw the datatable each time
    //a user selects a new filter.
    // $(".countryFilter").change(function (e) {
    //   table.draw();
    // });
    // $(".sectorFilter").change(function (e) {
    //   table.draw();
    // });
    // $(".planFilter").change(function (e) {
    //   table.draw();
    // });
    // $(".statusFilter").change(function (e) {
    //   table.draw();
    // });
    table.draw();
});
$("document").ready(function () {

    $("#dataTableCTDconsult").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
            
          ]
        },{
              text: '<i class="bx bx-plus-circle me-sm-2"></i> <span class="d-none d-sm-inline-block">Add New CTD</span>',
              className: 'addPackages btn btn-primary',
              attr: {
                'data-bs-toggle': 'offcanvas',
                'data-bs-target': '#addData'
              }
            }
      ],
    });
    //Get a reference to the new datatable
    var table = $('#dataTableCTDconsult').DataTable();
    table.draw();
});
$("document").ready(function () {

    $("#dataTableCartlist").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
            
          ]
        },{
              text: '<i class="bx bx-plus-circle me-sm-2"></i> <span class="d-none d-sm-inline-block">Add New CTD</span>',
              className: 'addPackages btn btn-primary',
              attr: {
                'data-bs-toggle': 'offcanvas',
                'data-bs-target': '#addData'
              }
            }
      ],
    });
    //Get a reference to the new datatable
    var table = $('#dataTableCartlist').DataTable();
    table.draw();
});
$("document").ready(function () {

    $("#dataTableWishlist").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
            
          ]
        },{
              text: '<i class="bx bx-plus-circle me-sm-2"></i> <span class="d-none d-sm-inline-block">Add New CTD</span>',
              className: 'addPackages btn btn-primary',
              attr: {
                'data-bs-toggle': 'offcanvas',
                'data-bs-target': '#addData'
              }
            }
      ],
    });
    //Get a reference to the new datatable
    var table = $('#dataTableWishlist').DataTable();
    table.draw();
});
$("document").ready(function () {

    $("#dataTableCTDapproval").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
            
          ]
        },{
              text: '<i class="bx bx-plus-circle me-sm-2"></i> <span class="d-none d-sm-inline-block">Add New CTD</span>',
              className: 'addPackages btn btn-primary',
              attr: {
                'data-bs-toggle': 'offcanvas',
                'data-bs-target': '#addData'
              }
            }
      ],
    });
    //Get a reference to the new datatable
    var table = $('#dataTableCTDapproval').DataTable();
    table.draw();
});
$("document").ready(function () {

    $("#dataTableCTDrejected").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
            
          ]
        },{
              text: '<i class="bx bx-plus-circle me-sm-2"></i> <span class="d-none d-sm-inline-block">Add New CTD</span>',
              className: 'addPackages btn btn-primary',
              attr: {
                'data-bs-toggle': 'offcanvas',
                'data-bs-target': '#addData'
              }
            }
      ],
    });
    //Get a reference to the new datatable
    var table = $('#dataTableCTDrejected').DataTable();
    table.draw();
});
function AddLotItem() {
  var x = document.getElementById("CreateInput");
  x = x.value;
  let prSwtch = "";
  if (x>0) {
  prSwtch += `
    <hr class="mt-1">
    <label class="switch text-center w-100">
        <span class="switch-label text-primary" style="font-size: .7rem;">Single price for all
            lots.</span>
        <input type="checkbox" class="switch-input is-valid" />
        <span class="switch-toggle-slider">
            <span class="switch-on"></span>
            <span class="switch-off"></span>
        </span>
        <span class="switch-label text-success" style="font-size: .7rem;">Different price for each
            lots.</span>
    </label>
    <hr>
  `
  } else {
    prSwtch += "";
  }
  document.getElementById("prSwtch").innerHTML = prSwtch;
  let val  = parseInt(x)+1;
  console.log(val);
  let node = "";
  let nodePrice = "";
  for (let index = 1; index < val; index++) {
    // console.log(val);
    node += `
    <div class="my-3">
    <div class="form-floating">
  <textarea class="form-control" placeholder="Lot description here" id="floatingTextarea`+index+`" style="height: 100px"></textarea>
  <label for="floatingTextarea2">Lot `+index+`</label>
</div>
    </div>
    `;
    nodePrice += `
    <div class="row mb-3">
    <div class="col-6">
        <div class="input-group h-100">
            <span class="input-group-btn">
                <button type="button" class="p-1 h-100 btn btn-danger btn-number" data-type="minus"
                    data-field="quant">
                    <i class='bx bx-minus-circle'></i>
                </button>
            </span>
            <input type="text" name="quant" class="form-control input-number h-100" value="100000"
                min="100000" max="1000000000">
            <span class="input-group-btn">
                <button type="button" class="p-1 h-100 btn btn-success btn-number" data-type="plus"
                    data-field="quant">
                    <i class='bx bx-plus-circle'></i>
                </button>
            </span>
        </div>
    </div>
    <div class="col-6">
        <span style="font-size: .8rem;">Selling price per Download</span>
        <div class="d-flex justify-content-between" style="border-bottom: 1px dashed">
            <span class="text-success">167000 F CFA</span>
            <i class="fas fa-info-circle    " data-bs-toggle="tooltip" data-bs-placement="top"
                title="Tooltip Content"></i>
        </div>
    </div>
</div>
    `;
}
document.getElementById("lotsUser").innerHTML = node;
document.getElementById("lotsPrice").innerHTML = nodePrice;

}

$(function () {
  // $('.minus').click(function () {
  //   var $input = $(this).parent().find('input');
  //   var count = parseInt($input.val()) - 1;
  //   count = count < 1 ? 1 : count;
  //   $input.val(count);
  //   $input.change();
  //   return false;
  // });
  // $('.plus').click(function () {
  //   var $input = $(this).parent().find('input');
  //   $input.val(parseInt($input.val()) + 1);
  //   $input.change();
  //   return false;
  // });
  $('.btn-number').click(function(e){
    e.preventDefault();
    
    fieldName = $(this).attr('data-field');
    type      = $(this).attr('data-type');
    var input = $("input[name='"+fieldName+"']");
    var currentVal = parseInt(input.val());
    if (!isNaN(currentVal)) {
        if(type == 'minus') {
            
            if(currentVal > input.attr('min')) {
                input.val(currentVal - 150000).change();
            } 
            if(parseInt(input.val()) == input.attr('min')) {
                $(this).attr('disabled', true);
            }

        } else if(type == 'plus') {

            if(currentVal < input.attr('max')) {
                input.val(currentVal + 150000).change();
            }
            if(parseInt(input.val()) == input.attr('max')) {
                $(this).attr('disabled', true);
            }

        }
    } else {
        input.val(0);
    }
  });
$('.input-number').focusin(function(){
   $(this).data('oldValue', $(this).val());
});
$('.input-number').change(function() {
    
    minValue =  parseInt($(this).attr('min'));
    maxValue =  parseInt($(this).attr('max'));
    valueCurrent = parseInt($(this).val());
    
    name = $(this).attr('name');
    if(valueCurrent >= minValue) {
        $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the minimum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    if(valueCurrent <= maxValue) {
        $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the maximum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    
    
});
$(".input-number").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) || 
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
});

$(function () {
  // $("#CreateInput").select2({
  //   tags: true
  // });
  $('#CTDfunding').on('keyup', function () {
    // $('.floated-submit').css('display', 'block');
    var btnElem = $('.floated-submit2');
    var charLength = this.value.length;
    if (charLength > 0) {
        btnElem.slideDown();
    } else {
        btnElem.slideUp();
    }
  });
  $('#CTDtype').on('keyup', function () {
    // $('.floated-submit').css('display', 'block');
    var btnElem = $('.floated-submit');
    var charLength = this.value.length;
    if (charLength > 0) {
        btnElem.slideDown();
    } else {
        btnElem.slideUp();
    }
  });
  $('#search_exit_ctd, #Get').on('click', function () {
    let btnElem = $('.floated-submit');
    btnElem.slideUp(200);
  });  
  });
var canvas = document.getElementById('image');
var ctx = canvas.getContext('2d');

var img = new Image();

img.onload = function(){
canvas.width = img.naturalWidth
canvas.height = img.naturalHeight
ctx.drawImage(img, 0, 0);
}

img.src = 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/130527/yellow-flower.jpg';
  ClassicEditor
  .create( document.querySelector( '#editor' ) )
  .then( editor => {
    console.log( 'successful' );
  })
  .catch( error => {
    console.error( 'faile' );
  });

    //var client = filestack.init('AKe34NwoJRdmod7ug4rKwz');
// var client = filestack.init('ANheNfWrTwG57dC27QFEAz');
// var watermarkHandle = '';

// client.onFileSelected(file);

function openPicker() {
  console.log("open Water Picker");
  var fs_button = document.querySelector("#waterPicker");
  fs_button.addEventListener("click", function() {
    var client = filestack
    .init('ANheNfWrTwG57dC27QFEAz') // That's where we're using the localStorage <<--
    .picker({
      fromSources: [
        'local_file_system',
        'url',
        // 'imagesearch',
        'facebook',
        'instagram',
        'googledrive',
        'dropbox'
      ]
    }).open();
  });
  
  
}

