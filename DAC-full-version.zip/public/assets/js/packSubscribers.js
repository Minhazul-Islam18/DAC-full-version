$("document").ready(function () {

    $("#dataTable").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row px-0 border-top border-bottom mt-3 py-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
          ]
        }
      ],
    });
    //Get a reference to the new datatable
    var table = $('#dataTable').DataTable();

    //Take the lots filter drop down and append it to the datatables_filter div. 
    //You can use this same idea to move the filter anywhere withing the datatable that you want.
    // $("#dataTable_filter.dataTables_filter").append($("#lotsFilter"));
    // $("#dataTable_filter.dataTables_filter").append($("#countryFilter"));
    
    //Get the column index for the lots column to be used in the method below ($.fn.dataTable.ext.search.push)
    //This tells datatables what column to filter on when a user selects a value from the dropdown.
    //It's important that the text used here (lots) is the same for used in the header of the column to filter
    var planIndex = 0;
    $("#dataTable th").each(function (i) {
      if ($($(this)).html() == "Plan (Packages)") {
        planIndex = i; return false;
      }
    });
    var typeIndex = 0;
    $("#dataTable th").each(function (i) {
      if ($($(this)).html() == "Type") {
        typeIndex = i; return false;
      }
    });
    var statusIndex = 0;
    $("#dataTable th").each(function (i) {
      if ($($(this)).html() == "Status") {
        statusIndex = i; return false;
      }
    });

    //Use the built in datatables API to filter the existing rows by the lots column
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('#packageFilter').val()
        var plan = data[planIndex];
        if (selectedItem === "" || plan.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('#typeFilter').val()
        var type = data[typeIndex];
        if (selectedItem === "" || type.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('#statusFilter').val()
        var status = data[statusIndex];
        if (selectedItem === "" || status.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );

    //Set the change event for the lots Filter dropdown to redraw the datatable each time
    //a user selects a new filter.
    $("#packageFilter").change(function (e) {
      table.draw();
    });
    $("#typeFilter").change(function (e) {
      table.draw();
    });
    $("#statusFilter").change(function (e) {
      table.draw();
    });

    table.draw();
  });
//   $(function () {
//     var bsDatepickerRange2 = $('.bs-datepicker-daterange');
//       bsDatepickerRange2.datepicker({
//         todayHighlight: true,
//         orientation: isRtl ? 'auto right' : 'auto left'
//       });
    
//   })
// $(function () {
//     if (document.getElementsByClassName('typeSwicther').checked) {
//         $(".forConsult").style.display === "none";

//     } else {
//         // Pro package is checked
//         document.calculator.total.value = p;

//     }
// })
// $(function() {
//     $(".consult").prop("checked", true);
//     $(".consult").data("ischecked", true);
  
//     $('form').on('click', ':radio', function() {
//       var status = $(this).data('ischecked'); //get status
//       status && $(this).prop("checked", false); //uncheck if checked
//       $(this).data('ischecked', !status); //toggle status        
//       if (this.id == "unconfirmed") $(".consult").prop("checked", !this.checked)
//     });
//   });
