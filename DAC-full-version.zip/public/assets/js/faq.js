/**
 * FAQ
 */

'use strict';

$("document").ready(function () {

    $("#dataTable").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
          ]
        },
        {
          text: '<i class="bx bx-plus-circle me-sm-2"></i> <span class="d-none d-sm-inline-block">Add FAQ</span>',
          className: 'addPackages btn btn-primary',
          attr: {
            'data-bs-toggle': 'offcanvas',
            'data-bs-target': '#addBlog'
          }
        }
      ],
    });
  
    //Get a reference to the new datatable
    var table = $('#dataTable').DataTable();
  
    //Take the lots filter drop down and append it to the datatables_filter div. 
    //You can use this same idea to move the filter anywhere withing the datatable that you want.
    // $("#dataTable_filter.dataTables_filter").append($("#lotsFilter"));
    // $("#dataTable_filter.dataTables_filter").append($("#countryFilter"));
    
    //Get the column index for the lots column to be used in the method below ($.fn.dataTable.ext.search.push)
    //This tells datatables what column to filter on when a user selects a value from the dropdown.
    //It's important that the text used here (lots) is the same for used in the header of the column to filter

    var categoryIndex = 0;
    $("#dataTable th").each(function (i) {
      if ($($(this)).html() == "Title") {
        categoryIndex = i; return false;
      }
    });
    var statusIndex = 0;
    $("#dataTable th").each(function (i) {
      if ($($(this)).html() == "Status") {
        statusIndex = i; return false;
      }
    });
  
    //Use the built in datatables API to filter the existing rows by the lots column
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.categoryFilter').val()
        var category = data[categoryIndex];
        if (selectedItem === "" || category.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.statusFilter').val()
        var status = data[statusIndex];
        if (selectedItem === "" || status.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
  
    //Set the change event for the lots Filter dropdown to redraw the datatable each time
    //a user selects a new filter.
    $(".categoryFilter").change(function (e) {
      table.draw();
    });
    $(".statusFilter").change(function (e) {
      table.draw();
    });
    table.draw();
  });
  ClassicEditor
  .create( document.querySelector( '#editor' ) )
  .then( editor => {
    console.log( 'successful' );
  })
  .catch( error => {
    console.error( 'faile' );
  });
(function () {
  // Custom list & inline suggestion
  //------------------------------------------------------
//   const TagifyCustomInlineSuggestionEl = document.querySelector('#TagifyCustomInlineSuggestion');
  const TagifyCustomListSuggestionEl = document.querySelector('.classy4');

  const whitelist = [
    'A# .NET',
    'A# (Axiom)',
    'A-0 System'
  ];

  // List
  let TagifyCustomListSuggestion = new Tagify(TagifyCustomListSuggestionEl, {
    whitelist: whitelist,
    maxTags: 10,
    dropdown: {
      maxItems: 20,
      classname: '',
      enabled: 0,
      closeOnSelect: false
    }
  });
})();
(function () {
  // Custom list & inline suggestion
  //------------------------------------------------------
//   const TagifyCustomInlineSuggestionEl = document.querySelector('#TagifyCustomInlineSuggestion');
  const TagifyCustomListSuggestionEl = document.querySelector('.classy');

  const whitelist = [
    'A# .NET',
    'A# (Axiom)',
    'A-0 System'
  ];

  // List
  let TagifyCustomListSuggestion = new Tagify(TagifyCustomListSuggestionEl, {
    whitelist: whitelist,
    maxTags: 10,
    dropdown: {
      maxItems: 20,
      classname: '',
      enabled: 0,
      closeOnSelect: false
    }
  });
})();
(function () {
  // Custom list & inline suggestion
  //------------------------------------------------------
//   const TagifyCustomInlineSuggestionEl = document.querySelector('#TagifyCustomInlineSuggestion');
  const TagifyCustomListSuggestionEl = document.querySelector('.classy2');

  const whitelist = [
    'A# .NET',
    'A# (Axiom)',
    'A-0 System'
  ];

  // List
  let TagifyCustomListSuggestion = new Tagify(TagifyCustomListSuggestionEl, {
    whitelist: whitelist,
    maxTags: 10,
    dropdown: {
      maxItems: 20,
      classname: '',
      enabled: 0,
      closeOnSelect: false
    }
  });
})();
(function () {
  // Custom list & inline suggestion
  //------------------------------------------------------
//   const TagifyCustomInlineSuggestionEl = document.querySelector('#TagifyCustomInlineSuggestion');
  const TagifyCustomListSuggestionEl = document.querySelector('.classy3');

  const whitelist = [
    'A# .NET',
    'A# (Axiom)',
    'A-0 System'
  ];

  // List
  let TagifyCustomListSuggestion = new Tagify(TagifyCustomListSuggestionEl, {
    whitelist: whitelist,
    maxTags: 10,
    dropdown: {
      maxItems: 20,
      classname: '',
      enabled: 0,
      closeOnSelect: false
    }
  });




      // First register any plugins
      // $.fn.filepond.registerPlugin(FilePondPluginImagePreview);

      // // Turn input element into a pond
      // $("input[type='file']").filepond();
  
      // // Set allowMultiple property to true
      // $("input[type='file']").filepond('allowMultiple', true);
    
      // // Listen for addfile event
      // $("input[type='file']").on('FilePond:addfile', function(e) {
      //     console.log('file added event', e);
      // });
  
      // // Manually add a file using the addfile method
      // $("input[type='file']").first().filepond('addFile', 'index.html').then(function(file){
      //   console.log('file added', file);
      // });
})();
