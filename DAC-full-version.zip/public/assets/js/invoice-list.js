$("document").ready(function () {

    $("#dataTable").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
          ]
        },
        {
          text: '<i class="bx bx-plus-circle me-sm-2"></i> <span class="d-none d-sm-inline-block">Create Invoice</span>',
          className: 'addPackages btn btn-primary',
          attr: {
            'data-bs-toggle': 'modal',
            'data-bs-target': '#addInvoice'
          }
        }
      ],
    });
  
    //Get a reference to the new datatable
    var table = $('#dataTable').DataTable();
  
    //Take the lots filter drop down and append it to the datatables_filter div. 
    //You can use this same idea to move the filter anywhere withing the datatable that you want.
    // $("#dataTable_filter.dataTables_filter").append($("#lotsFilter"));
    // $("#dataTable_filter.dataTables_filter").append($("#countryFilter"));
    
    //Get the column index for the lots column to be used in the method below ($.fn.dataTable.ext.search.push)
    //This tells datatables what column to filter on when a user selects a value from the dropdown.
    //It's important that the text used here (lots) is the same for used in the header of the column to filter
    var countryIndex = 0;
    $("#dataTable th").each(function (i) {
      if ($($(this)).html() == "Client") {
        countryIndex = i; return false;
      }
    });
    var statusIndex = 0;
    $("#dataTable th").each(function (i) {
      if ($($(this)).html() == "Balance") {
        statusIndex = i; return false;
      }
    });
    var CTDstatusIndex = 0;
    $("#dataTable th").each(function (i) {
      if ($($(this)).html() == "Balance") {
        CTDstatusIndex = i; return false;
      }
    });
    var paymentMethodIndex = 0;
    $("#dataTable th").each(function (i) {
      if ($($(this)).html() == "Balance") {
        paymentMethodIndex = i; return false;
      }
    });
  
    //Use the built in datatables API to filter the existing rows by the lots column
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.countryFilter').val()
        var country = data[countryIndex];
        if (selectedItem === "" || country.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.statusFilter').val()
        var status = data[statusIndex];
        if (selectedItem === "" || status.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.CTDstatusFilter').val()
        var CTDstatus = data[CTDstatusIndex];
        if (selectedItem === "" || CTDstatus.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.paymentMethod').val()
        var paymentMethod = data[paymentMethodIndex];
        if (selectedItem === "" || paymentMethod.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
  
    //Set the change event for the lots Filter dropdown to redraw the datatable each time
    //a user selects a new filter.
    $(".countryFilter").change(function (e) {
      table.draw();
    });
    $(".statusFilter").change(function (e) {
      table.draw();
    });
    $(".CTDstatusFilter").change(function (e) {
      table.draw();
    });
    $(".paymentMethod").change(function (e) {
      table.draw();
    });
    table.draw();
  });
  // ClassicEditor
  //   .create( document.querySelector( '#editor' ) )
  //   .then( editor => {
  //     console.log( 'successful' );
  //   })
  //   .catch( error => {
  //     console.error( 'faile' );
  //   });
  
  // var room = 1;
  // function education_fields() {
   
  //     room++;
  //     var objTo = document.getElementById('education_fields')
  //     var divtest = document.createElement("div");
  // 	divtest.setAttribute("class", "form-group removeclass"+room);
  // 	var rdiv = 'removeclass'+room;
  //     divtest.innerHTML = 
  //     `
  //     <div class="container-fluid p-0">
  //     <div class="row">
  //         <div class="col-9 nopadding">
  //             <div class="form-group">
  //             <input type="text" class="form-control" id="Schoolname" name="Schoolname[]" value="" placeholder="School name">
  //             </div>
  //         </div> 
  //         <div class="col-3 nopadding">
  //             <div class="input-group-btn d-flex justify-content-end">
  //                 <button class="btn btn-danger" type="button" onclick="remove_education_fields('+ room +');">
  //                     <i class="fa-solid fa-minus"></i> 
  //                 </button>
  //             </div>
  //         </div>            
  //     </div>                
  // </div>
  // </div>
  //     `;
      
  //     objTo.appendChild(divtest)
  // }
  //    function remove_education_fields(rid) {
  // 	   $('.removeclass'+rid).remove();
  //    }
     
//   var room = 1;
//   function education_fields() {
   
//       room++;
//       var objTo = document.getElementById('education_fields')
//       var divtest = document.createElement("div");
//       divtest.setAttribute("class", "form-group removeclass"+room);
//       var rdiv = 'removeclass'+room;
//       divtest.innerHTML = '<div class="col-9 nopadding"><div class="form-group"><input type="text" class="form-control" id="Schoolname" name="Schoolname[]" value="" placeholder="Enter Ministry"></div></div><div class="col-3 nopadding d-flex justify-content-end"><div class="form-group"><div class="input-group"><div class="input-group-btn"> <button class="btn btn-danger" type="button" onclick="remove_education_fields('+ room +');"> <i class="fa-solid fa-minus"></i> </button></div></div></div></div><div class="clear"></div>';
      
//       objTo.appendChild(divtest)
//   }
//      function remove_education_fields(rid) {
//          $('.removeclass'+rid).remove();
//      }

table.on('draw', function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl, {
        boundary: document.body
      });
    });
  });
  document.addEventListener('DOMContentLoaded', function (e) {
    (function () {
      // Variables
      const creditCardMask = document.querySelector('.credit-card-mask'),
        expiryDateMask = document.querySelector('.expiry-date-mask'),
        cvvMask = document.querySelector('.cvv-code-mask'),
        btnReset = document.querySelector('.btn-reset');
      let cleave;
  
      // Credit Card
      function initCleave() {
        if (creditCardMask) {
          cleave = new Cleave(creditCardMask, {
            creditCard: true,
            onCreditCardTypeChanged: function (type) {
              if (type != '' && type != 'unknown') {
                document.querySelector('.card-type').innerHTML =
                  '<img src="' +
                  assetsPath +
                  'img/icons/payments/' +
                  type +
                  '-cc.png" class="cc-icon-image" height="28"/>';
              } else {
                document.querySelector('.card-type').innerHTML = '';
              }
            }
          });
        }
      }
  
      // Init cleave on show modal (To fix the cc image issue)
      let addNewCCModal = document.getElementById('addNewCCModal');
      addNewCCModal.addEventListener('show.bs.modal', function (event) {
        initCleave();
      });
  
    //   // Expiry Date Mask
    //   if (expiryDateMask) {
    //     new Cleave(expiryDateMask, {
    //       date: true,
    //       delimiter: '/',
    //       datePattern: ['m', 'y']
    //     });
    //   }
  
    //   // CVV
    //   if (cvvMask.length) {
    //     new Cleave(cvvMask, {
    //       numeral: true,
    //       numeralPositiveOnly: true
    //     });
    //   }
  
    //   // Credit card form validation
    //   FormValidation.formValidation(document.getElementById('addNewCCForm'), {
    //     fields: {
    //       modalAddCard: {
    //         validators: {
    //           notEmpty: {
    //             message: 'Please enter your credit card number'
    //           }
    //         }
    //       }
    //     },
    //     plugins: {
    //       trigger: new FormValidation.plugins.Trigger(),
    //       bootstrap5: new FormValidation.plugins.Bootstrap5({
    //         // Use this for enabling/changing valid/invalid class
    //         // eleInvalidClass: '',
    //         eleValidClass: '',
    //         rowSelector: '.col-12'
    //       }),
    //       submitButton: new FormValidation.plugins.SubmitButton(),
    //       // Submit the form when all fields are valid
    //       // defaultSubmit: new FormValidation.plugins.DefaultSubmit(),
    //       autoFocus: new FormValidation.plugins.AutoFocus()
    //     },
    //     init: instance => {
    //       instance.on('plugins.message.placed', function (e) {
    //         //* Move the error message out of the `input-group` element
    //         if (e.element.parentElement.classList.contains('input-group')) {
    //           e.element.parentElement.insertAdjacentElement('afterend', e.messageElement);
    //         }
    //       });
    //     }
    //   }).on('plugins.message.displayed', function (e) {
    //     if (e.element.parentElement.classList.contains('input-group')) {
    //       //* Move the error message out of the `input-group` element
    //       e.element.parentElement.insertAdjacentElement('afterend', e.messageElement.parentElement);
    //     }
    //   });
  
    //   // reset card image on click of cancel
    //   btnReset.addEventListener('click', function (e) {
    //     // blank '.card-type' innerHTML to remove image
    //     document.querySelector('.card-type').innerHTML = '';
    //     // destroy cleave and init again on modal open
    //     cleave.destroy();
    //   });
    })();
  });
  