/**
 * Blog
 */

$("document").ready(function () {

    $("#invoiceUview").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
          ]
        },
      ],
    });
  
    //Get a reference to the new datatable
    var table = $('#invoiceUview').DataTable();
  
    //Take the lots filter drop down and append it to the datatables_filter div. 
    //You can use this same idea to move the filter anywhere withing the datatable that you want.
    // $("#dataTable_filter.dataTables_filter").append($("#lotsFilter"));
    // $("#dataTable_filter.dataTables_filter").append($("#countryFilter"));
    
    //Get the column index for the lots column to be used in the method below ($.fn.dataTable.ext.search.push)
    //This tells datatables what column to filter on when a user selects a value from the dropdown.
    //It's important that the text used here (lots) is the same for used in the header of the column to filter

    var countryIndex = 0;
    $("#invoiceUview th").each(function (i) {
      if ($($(this)).html() == "ID") {
        countryIndex = i; return false;
      }
    });
    var invoiceIndex = 0;
    $("#invoiceUview th").each(function (i) {
      if ($($(this)).html() == "ID") {
        invoiceIndex = i; return false;
      }
    });
    var paymentIndex = 0;
    $("#invoiceUview th").each(function (i) {
      if ($($(this)).html() == "ID") {
        paymentIndex = i; return false;
      }
    });
    //Use the built in datatables API to filter the existing rows by the lots column
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.countryFilter').val()
        var country = data[countryIndex];
        if (selectedItem === "" || country.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.iStatusFilter').val()
        var invoice = data[invoiceIndex];
        if (selectedItem === "" || invoice.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.payMethodFilter').val()
        var payment = data[paymentIndex];
        if (selectedItem === "" || payment.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
  
    //Set the change event for the lots Filter dropdown to redraw the datatable each time
    //a user selects a new filter.
    $(".countryFilter").change(function (e) {
      table.draw();
    });
    $(".iStatusFilter").change(function (e) {
      table.draw();
    });
    $(".payMethodFilter").change(function (e) {
      table.draw();
    });
    table.draw();
  });
$("document").ready(function () {

    $(".dataTableUaccount").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
          ]
        }
      ],
    });
  
    //Get a reference to the new datatable
    var table = $('.dataTableUaccount').DataTable();
  
    //Take the lots filter drop down and append it to the datatables_filter div. 
    //You can use this same idea to move the filter anywhere withing the datatable that you want.
    // $("#dataTable_filter.dataTables_filter").append($("#lotsFilter"));
    // $("#dataTable_filter.dataTables_filter").append($("#countryFilter"));
    
    //Get the column index for the lots column to be used in the method below ($.fn.dataTable.ext.search.push)
    //This tells datatables what column to filter on when a user selects a value from the dropdown.
    //It's important that the text used here (lots) is the same for used in the header of the column to filter

    var countryIndex = 0;
    $(".dataTableUaccount th").each(function (i) {
      if ($($(this)).html() == "CTD List") {
        countryIndex = i; return false;
      }
    });
    var languageIndex = 0;
    $(".dataTableUaccount th").each(function (i) {
      if ($($(this)).html() == "CTD List") {
        languageIndex = i; return false;
      }
    });
    var lotsIndex = 0;
    $(".dataTableUaccount th").each(function (i) {
      if ($($(this)).html() == "Number of lots") {
        lotsIndex = i; return false;
      }
    });
    var fundingIndex = 0;
    $(".dataTableUaccount th").each(function (i) {
      if ($($(this)).html() == "CTD List") {
        fundingIndex = i; return false;
      }
    });
    var statusIndex = 0;
    $(".dataTableUaccount th").each(function (i) {
      if ($($(this)).html() == "CTD List") {
        statusIndex = i; return false;
      }
    });
  
    //Use the built in datatables API to filter the existing rows by the lots column
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.userViewCountry').val()
        var country = data[countryIndex];
        if (selectedItem === "" || country.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.userViewLanguage').val()
        var language = data[languageIndex];
        if (selectedItem === "" || language.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.userViewLots').val()
        var lots = data[lotsIndex];
        if (selectedItem === "" || lots.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );

    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.userViewFunding').val()
        var funding = data[fundingIndex];
        if (selectedItem === "" || funding.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );

    $.fn.dataTable.ext.search.push(
      function (settings, data, dataIndex) {
        var selectedItem = $('.userViewStatus').val()
        var status = data[statusIndex];
        if (selectedItem === "" || status.includes(selectedItem)) {
          return true;
        }
        return false;
      }
    );
  
    //Set the change event for the lots Filter dropdown to redraw the datatable each time
    //a user selects a new filter.
    $(".userViewCountry").change(function (e) {
      table.draw();
    });
    $(".userViewLanguage").change(function (e) {
      table.draw();
    });
    $(".userViewLots").change(function (e) {
      table.draw();
    });
    $(".userViewFunding").change(function (e) {
      table.draw();
    });
    $(".userViewStatus").change(function (e) {
      table.draw();
    });
    table.draw();
  });
