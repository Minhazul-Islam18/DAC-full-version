$("document").ready(function () {

    $(".dataTableUwallet").dataTable({
      "searching": true,
      dom: '<"card-header flex-column flex-md-row p-0 border-bottom pb-3"<"head-label text-center"><"dt-action-buttons text-end pt-3 pt-md-0"B>><"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
      buttons: [
        {
          extend: 'collection',
          className: 'btn btn-label-primary dropdown-toggle me-2',
          text: '<i class="bx bx-export me-sm-2"></i> <span class="d-none d-sm-inline-block">Export</span>',
          buttons: [
            {
              extend: 'print',
              text: '<i class="bx bx-printer me-2" ></i>Print',
              className: 'dropdown-item'
            },
            {
              extend: 'csv',
              text: '<i class="bx bx-file me-2" ></i>Csv',
              className: 'dropdown-item',
            },
            {
              extend: 'excel',
              text: 'Excel',
              className: 'dropdown-item'
            },
            {
              extend: 'pdf',
              text: '<i class="bx bxs-file-pdf me-2"></i>Pdf',
              className: 'dropdown-item'
            },
            {
              extend: 'copy',
              text: '<i class="bx bx-copy me-2" ></i>Copy',
              className: 'dropdown-item'
            }
          ]
        }
      ],
    });
  
    //Get a reference to the new datatable
    var table = $('.dataTableUwallet').DataTable();
  
    //Take the lots filter drop down and append it to the datatables_filter div. 
    //You can use this same idea to move the filter anywhere withing the datatable that you want.
    // $("#dataTable_filter.dataTables_filter").append($("#lotsFilter"));
    // $("#dataTable_filter.dataTables_filter").append($("#countryFilter"));
    
    //Get the column index for the lots column to be used in the method below ($.fn.dataTable.ext.search.push)
    //This tells datatables what column to filter on when a user selects a value from the dropdown.
    //It's important that the text used here (lots) is the same for used in the header of the column to filter

    // var purposeIndex = 0;
    // $(".dataTableUwallet th").each(function (i) {
    //   if ($($(this)).html() == "ID") {
    //     purposeIndex = i; return false;
    //   }
    // });
    // var methodIndex = 0;
    // $(".dataTableUwallet th").each(function (i) {
    //   if ($($(this)).html() == "ID") {
    //     methodIndex = i; return false;
    //   }
    // });
  
    //Use the built in datatables API to filter the existing rows by the lots column
    // $.fn.dataTable.ext.search.push(
    //   function (settings, data, dataIndex) {
    //     var selectedItem = $('.userPurpose').val();
    //     var purpose = data[purposeIndex];
    //     if (selectedItem === "" || purpose.includes(selectedItem)) {
    //       return true;
    //     }
    //     return false;
    //   }
    // );
    // $.fn.dataTable.ext.search.push(
    //   function (settings, data, dataIndex) {
    //     var selectedItem = $('.userPayPurpose').val();
    //     var method = data[methodIndex];
    //     if (selectedItem === "" || method.includes(selectedItem)) {
    //       return true;
    //     }
    //     return false;
    //   }
    // );

  
    //Set the change event for the lots Filter dropdown to redraw the datatable each time
    //a user selects a new filter.
    // $(".userPurpose").change(function (e) {
    //   table.draw();
    // });
    // $(".userPayPurpose").change(function (e) {
    //   table.draw();
    // });
    table.draw();
  });

