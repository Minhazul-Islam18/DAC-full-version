$('.switch label').on('click', function(){
    var indicator = $(this).parent('.switch').find('span');
    if ( $(this).hasClass('right') ){
          $(indicator).addClass('right');
    } else {
      $(indicator).removeClass('right');
    }
  });